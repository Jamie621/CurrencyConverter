
TODOs:

In groups of 4, complete the following tasks, 1 for each team member:
1. Extract all the strings into the **strings.xml** file and use them in the layout and the activity
2. Change the theme of the app to a **NoActionBar** theme and modify the primary colors
3. Add **Log** messages at the entry/exit of **onCreate()** and **convertCurrency()** methods. Level should be **Info**
4. Add **ViewBinding** to the project

    - Each task must be done in a separate branch and merged to the main branch
    after completion using a Pull Request.
    - Each task must be done by a different team member.
